from __future__ import absolute_import
from rouge.rouge import FilesRouge, Rouge

__version__ = "1.0.1"
__all__ = ["FilesRouge", "Rouge"]
